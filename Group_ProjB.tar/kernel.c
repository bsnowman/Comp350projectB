void printString(char*);
void readString(char*);
void readSector(char*, int);
void handleInterrupt21(int, int, int, int);


void main()
{
	char buffer[512];
	char line[80];
//	readSector(buffer,30);
//      printString(buffer);
	printString("Enter a line: \0");
//	readString(line);
//	printString(line);
	makeInterrupt21();
	interrupt(0x21,1,line,0,0);
	interrupt(0x21,0,line,0,0);
	readSector(buffer,30);
	printString(buffer);
	while(1);
}

void handleInterrupt21(int ax, int bx, int cx, int dx)
{
	if(ax == 0)
	{
	printString(bx);

	}
	else if(ax == 1)
	{
	readString(bx);
	}
	else if(ax ==2)
	{
	readSector(bx,cx);
	}
	else
	{
	printString("Error! \0");
	}
}



void readSector(char* buffer,int sector)
{
	int ah = 2;
	int al = 1;
	int bx = buffer;
	int ch = 0;
	int cl = sector +1;
	int dh = 0;
	int dl = 0x80;

	int ax = ah*256+al;
	int cx = ch*256+cl;
	int dx = dh*256 +dl;

	interrupt(0x13,ax,bx,cx,dx);
}

void printString(char* chars)
{
	int c = 0;
	while(chars[c]!=0)
	{
		char al  =chars[c];
		char ah = 0xe;
		int ax = ah*256+al;
		interrupt(0x10, ax, 0, 0, 0);
		c++;
	}



}


void readString(char* line)
{
	//int x =0;
	char in = 0;
	int start = 0;
	while(in != '\r')
	{
		in = interrupt(0x16, 0);
		//start++;
		if(in =='\b'&&start > 0)
		{
		//	if(x<= 0)
		//	{
			*(line-1) = in;
			interrupt(0x10, 0xe * 256 + '\b', 0, 0, 0);
			interrupt(0x10, 0xe * 256 + ' ', 0, 0, 0);
			interrupt(0x10, 0xe * 256 + '\b', 0, 0, 0);
			line--;
			start--;
		//	x--;
		//	}
		}

		else if (in != '\b')
		{
			*line = in;
			interrupt(0x10, 0xe * 256 + *line, 0, 0, 0);
			line++;
			start++;
		//	x++;
		}
	}

	*line = '\n';
	interrupt(0x10, 0xe*256+*line, 0 ,0 ,0);
	line++;
	*line = '\0';

}
