void printString(char*);
void readString(char*);

void main()
{
	char line[80];
	printString("Enter a line: \0");
	readString(line);
	printString(line);
	while(1);
}


void printString(char* chars)
{
	int c = 0;
	while(chars[c]!=0)
	{
		char al  =chars[c];
		char ah = 0xe;
		int ax = ah*256+al;
		interrupt(0x10, ax, 0, 0, 0);
		c++;
	}
}

void readString(char* line)
{
	char in = 0;
	while(in != '\r')
	{
		in = interrupt(0x16, 0);

		if(in =='\b')
		{
			*(line-1) = in;
			interrupt(0x10, 0xe * 256 + '\b', 0, 0, 0);
			interrupt(0x10, 0xe * 256 + ' ', 0, 0, 0);
			interrupt(0x10, 0xe * 256 + '\b', 0, 0, 0);
			line--;
		}

		else
		{
			*line = in;
			interrupt(0x10, 0xe * 256 + *line, 0, 0, 0);
			line++;
		}
	}

	*line = '\n';
	interrupt(0x10, 0xe*256+*line, 0 ,0 ,0);
	line++;
	*line = '\0';

}
